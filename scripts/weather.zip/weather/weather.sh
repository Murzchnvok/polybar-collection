#!/bin/sh

python3 $HOME/polybar-collection/scripts/weather/weather.py -u metric
